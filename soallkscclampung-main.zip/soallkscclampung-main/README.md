INI ADALAH WEBSITE TEMPLATE UNTUK SOAL LKS CLOUD COMPUTING DI PROVINSI LAMPUNG

Keterangan :
1. Website ini tidak 100% selesai
2. Silahkan sesuaikan konten dari website ini dengan tema yang sudah anda pilih, Baik itu asset / gambar / icon dsbnya
3. File database sudah disediakan, file database tersebut juga tidak 100% sesuai dengan source code, silahkan sesuaikan !
